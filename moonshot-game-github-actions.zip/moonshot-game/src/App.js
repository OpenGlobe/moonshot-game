import React, { useState, useEffect } from 'react';

// Full updated code with resample Power-Up and back navigation from final screen
export default function MoonshotGame() {
  ...
  // (trimmed for brevity; full content already resides in the canvas document)
  ...
}
